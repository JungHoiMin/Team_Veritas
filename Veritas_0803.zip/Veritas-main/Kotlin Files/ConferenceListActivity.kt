package kr.co.veritas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ConferenceListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conference_list)
    }
}